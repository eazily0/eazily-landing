﻿window.EAZILY_CONFIG = {
  supabaseUrl: "https://rujrweqttrqdmkkbamjt.supabase.co",
  supabaseAnonKey: "sb_publishable_RX12DFwvaZmdK8E-fOcg2Q_y69S_m6v"
};

